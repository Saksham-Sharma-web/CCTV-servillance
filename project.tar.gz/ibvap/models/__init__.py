"""
Model storage package.
"""
